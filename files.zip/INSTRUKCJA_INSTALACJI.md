# 📱 Plan Pracy Handlowców - Aplikacja PWA

## ✨ Aplikacja gotowa do instalacji!

Twoja aplikacja jest teraz Progressive Web App (PWA) - może działać jak natywna aplikacja na telefonie i komputerze!

---

## 📥 Jak zainstalować aplikację?

### Na telefonie Android:
1. Otwórz plik `plan_pracy_multiuser.html` w przeglądarce Chrome
2. Kliknij menu (3 kropki) w prawym górnym rogu
3. Wybierz **"Dodaj do ekranu głównego"** lub **"Zainstaluj aplikację"**
4. Potwierdź instalację
5. Ikona aplikacji pojawi się na ekranie głównym!

### Na iPhone/iPad:
1. Otwórz plik `plan_pracy_multiuser.html` w Safari
2. Kliknij przycisk "Udostępnij" (kwadrat ze strzałką)
3. Przewiń w dół i wybierz **"Dodaj do ekranu głównego"**
4. Nazwij aplikację i kliknij "Dodaj"
5. Ikona aplikacji pojawi się na ekranie głównym!

### Na komputerze (Chrome/Edge):
1. Otwórz plik `plan_pracy_multiuser.html` w przeglądarce
2. Kliknij ikonę instalacji w pasku adresu (➕ lub komputer)
3. Lub kliknij menu (3 kropki) → **"Zainstaluj Plan Pracy Handlowców"**
4. Potwierdź instalację
5. Aplikacja otworzy się w osobnym oknie!

---

## 🚀 Funkcje aplikacji PWA:

✅ **Działa offline** - możesz pracować bez internetu
✅ **Szybkie ładowanie** - aplikacja ładuje się natychmiast
✅ **Wygląda jak aplikacja** - pełnoekranowy widok bez paska przeglądarki
✅ **Ikona na pulpicie** - łatwy dostęp z ekranu głównego
✅ **Automatyczne aktualizacje** - aplikacja sama się aktualizuje
✅ **Synchronizacja danych** - dane synchronizują się automatycznie między urządzeniami

---

## 📂 Pliki aplikacji:

- `plan_pracy_multiuser.html` - główny plik aplikacji
- `manifest.json` - konfiguracja aplikacji PWA
- `service-worker.js` - obsługa offline i cache
- `icon-192.png` - ikona aplikacji (mała)
- `icon-512.png` - ikona aplikacji (duża)

---

## 🌐 Jak uruchomić aplikację online?

Aby aplikacja działała online i synchronizowała dane między wszystkimi użytkownikami:

### Opcja 1: GitHub Pages (DARMOWE)
1. Załóż konto na GitHub.com
2. Utwórz nowe repozytorium
3. Prześlij wszystkie pliki
4. Włącz GitHub Pages w ustawieniach
5. Twoja aplikacja będzie dostępna pod adresem: `https://twoja-nazwa.github.io/nazwa-repo`

### Opcja 2: Netlify/Vercel (DARMOWE)
1. Załóż konto na Netlify.com lub Vercel.com
2. Przeciągnij folder z plikami
3. Aplikacja zostanie automatycznie opublikowana
4. Otrzymasz darmowy link HTTPS

### Opcja 3: Własny serwer
Prześlij wszystkie pliki na swój serwer WWW i udostępnij przez HTTPS.

---

## 💡 Wskazówki:

- Aplikacja najlepiej działa przez HTTPS (bezpieczne połączenie)
- Po zainstalowaniu możesz pracować offline
- Dane synchronizują się automatycznie gdy pojawi się internet
- Każdy handlowiec instaluje aplikację na swoim telefonie/komputerze
- Wszyscy widzą te same dane w czasie rzeczywistym

---

## 🆘 Rozwiązywanie problemów:

**Nie widzę opcji "Dodaj do ekranu głównego"?**
- Upewnij się, że otwierasz przez HTTPS lub localhost
- Spróbuj w innej przeglądarce (Chrome, Safari, Edge)

**Aplikacja nie synchronizuje danych?**
- Sprawdź połączenie z internetem
- Odśwież aplikację (pociągnij w dół)
- Wyloguj się i zaloguj ponownie

**Jak zaktualizować aplikację?**
- Aplikacja aktualizuje się automatycznie
- Możesz też odinstalować i zainstalować ponownie

---

## 📞 Kontakt:

Jeśli masz pytania lub problemy, skontaktuj się z administratorem systemu.

Miłej pracy! 🎉
