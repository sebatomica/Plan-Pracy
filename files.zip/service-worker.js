const CACHE_NAME = 'plan-pracy-v1';
const urlsToCache = [
  './plan_pracy_multiuser.html',
  './manifest.json'
];

// Instalacja Service Worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache otwarty');
        return cache.addAll(urlsToCache);
      })
  );
  self.skipWaiting();
});

// Aktywacja Service Worker
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('Usuwanie starego cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Strategia: Network First, potem Cache
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Zapisz kopię w cache
        const responseClone = response.clone();
        caches.open(CACHE_NAME).then(cache => {
          cache.put(event.request, responseClone);
        });
        return response;
      })
      .catch(() => {
        // Jeśli nie ma sieci, zwróć z cache
        return caches.match(event.request);
      })
  );
});

// Obsługa sync w tle (opcjonalne)
self.addEventListener('sync', event => {
  if (event.tag === 'sync-data') {
    event.waitUntil(syncData());
  }
});

async function syncData() {
  console.log('Synchronizacja danych w tle...');
  // Tutaj można dodać logikę synchronizacji
}

// Obsługa powiadomień push (opcjonalne)
self.addEventListener('push', event => {
  const options = {
    body: event.data ? event.data.text() : 'Nowe powiadomienie',
    icon: 'icon-192.png',
    badge: 'icon-192.png',
    vibrate: [200, 100, 200]
  };

  event.waitUntil(
    self.registration.showNotification('Plan Pracy', options)
  );
});
